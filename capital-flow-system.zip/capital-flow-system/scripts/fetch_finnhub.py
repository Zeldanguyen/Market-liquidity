"""
Lấy dữ liệu chứng khoán/FX toàn cầu từ Finnhub — MIỄN PHÍ (~60 request/phút)
Đăng ký API key tại: https://finnhub.io/register
"""
import os
import json
import urllib.request
from datetime import datetime

FINNHUB_KEY = os.environ.get("FINNHUB_API_KEY", "")
BASE_URL = "https://finnhub.io/api/v1"

# Symbol cho các chỉ số/ETF đại diện chính (Finnhub free tier mạnh nhất với US-listed)
SYMBOLS = {
    "sp500_etf": "SPY",      # S&P 500 ETF (proxy)
    "dow_etf": "DIA",        # Dow Jones ETF (proxy)
    "nasdaq_etf": "QQQ",     # Nasdaq ETF (proxy)
    "gold_etf": "GLD",       # Vàng ETF (proxy)
    "oil_etf": "USO",        # Dầu ETF (proxy)
    "dollar_etf": "UUP",     # USD Index ETF (proxy cho DXY)
    "vix_etf": "VXX",        # VIX proxy
    "china_etf": "FXI",      # Trung Quốc large-cap proxy
    "japan_etf": "EWJ",      # Nhật Bản proxy
    "vietnam_etf": "VNM",    # VanEck Vietnam ETF — proxy cho dòng vốn ngoại vào VN
}

FX_PAIRS = ["OANDA:USD_JPY", "OANDA:USD_CNH", "OANDA:USD_VND", "OANDA:EUR_USD"]


def fetch_quote(symbol):
    url = f"{BASE_URL}/quote?symbol={symbol}&token={FINNHUB_KEY}"
    try:
        with urllib.request.urlopen(url, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"error": str(e)}


def fetch_fx(pair):
    url = f"{BASE_URL}/forex/rates?base={pair.split('_')[0].split(':')[-1]}&token={FINNHUB_KEY}"
    try:
        with urllib.request.urlopen(url, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        return {"error": str(e)}


def main():
    result = {"fetched_at": datetime.utcnow().isoformat(), "equities": {}, "fx": {}}

    if not FINNHUB_KEY:
        result["status"] = "skipped_missing_key"
    else:
        result["status"] = "ok"
        for name, symbol in SYMBOLS.items():
            result["equities"][name] = fetch_quote(symbol)
        # FX rates lấy 1 lần (đã bao gồm nhiều cặp trong response)
        result["fx"]["usd_base_rates"] = fetch_fx("USD_JPY")

    os.makedirs("data", exist_ok=True)
    with open("data/finnhub.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print("Đã ghi data/finnhub.json")


if __name__ == "__main__":
    main()
